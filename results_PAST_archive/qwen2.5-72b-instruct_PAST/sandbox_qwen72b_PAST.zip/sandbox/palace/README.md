# Palace Directory
This directory contains palace-related files.