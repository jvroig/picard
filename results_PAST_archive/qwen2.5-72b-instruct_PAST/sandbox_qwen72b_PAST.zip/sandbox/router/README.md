# Router Configuration

This directory contains configuration files and documentation for the router setup.