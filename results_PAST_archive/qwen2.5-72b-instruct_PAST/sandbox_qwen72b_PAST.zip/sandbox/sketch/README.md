# Sketch Directory
This directory contains various sketches and notes.