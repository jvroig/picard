# Snake

This is the README for the snake directory.