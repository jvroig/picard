## Cliff Project

This is the README for the cliff directory.