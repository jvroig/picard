Epic project documentation
