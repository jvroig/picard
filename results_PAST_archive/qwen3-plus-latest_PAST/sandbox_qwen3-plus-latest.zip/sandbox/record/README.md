# Record Directory

This is the record directory structure as requested.