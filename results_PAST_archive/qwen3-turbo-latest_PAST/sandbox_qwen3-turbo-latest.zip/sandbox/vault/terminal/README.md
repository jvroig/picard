# Terminal

This is the terminal directory.