# Console Documentation

This directory contains console-related files.